// Define the PCX class in content.js
class PCX {

	static activeLabPortal = "";

	static setLabPortal(lab) {
		PCX.activeLabPortal = lab;
	}
	static preferedUserMode(){
		if(PCX.activeLabPortal == "PL") {
			console.log(PCX.currentUser());
			return PCX.currentUser() == "Max";
		}
		if(PCX.activeLabPortal == "PD" || PCX.activeLabPortal == "RR") {
			return true;
		}
		return false;
	}

	static patientData = {};
	static patientTransfer = {};
	static timerState = 0;

/**
 * 
 * Local Storage Operations
 * 
 */
	static events = {
		Space	: {bubbles: true, cancelable: true,	key: ' '},
		Delete	: {bubbles: true, cancelable: true,	shiftKey: false, keyCode: 8,	code: "Backspace",	key: "Backspace"},
		End		: {bubbles: true, cancelable: true,	shiftKey: false, keyCode: 35,	code: "END",		key: "END"},
		Tab		: {bubbles: true, cancelable: true,	shiftKey: false, keyCode: 9,	code: "Tab",		key: "Tab"},
		Enter	: {bubbles: true, cancelable: false,shiftKey: false, keyCode: 13,	code: "Enter",		key: "Enter"},

	};
	// Page Element points to avoid multiple queries
	static pageElementsCache = {};
	
	/**
	 * setLocalStorage 
	 * @param STRING		key		A unique idenifer for the storage to pull from later
	 * @param STRING(IFY)	value	Storaged as a string however the contents can be anything
	 *
	 * Used to add data to the storage
	 */
	static setLocalStorage(key, value) {
		chrome.storage.local.set({ [key]: value }, () => {
			PCX.log(`Stored ${key}: ${value}`);
		});
	}

	/**
	 * getLocalStorage 
	 * @param	STRING		key		A unique idenifer for the storage to pull from later
	 * @param	FUNCTION	value	A function to manipulate the returned value
	 * 
	 * @return 	FUNCTION			output of callback
	 *
	 * Used to recall data from the storage
	 */
	static getLocalStorage(key, callback) {
		try {
			chrome.storage.local.get(key, (result) => {
				PCX.log(`Fetched ${key}: ${result[key]}`);
				return callback(result[key]);
			});
		}catch(err) {
			console.log(err);
		}
	}


	/**
	 * clearLocalStorage 
	 * 
	 * Core functionality that purges all storage. Use With Caution!
	 */
	static clearLocalStorage() {
		chrome.storage.local.clear(() => {
			PCX.log("Local storage cleared");
		});
	}


	/**
	 * removeLocalStorage 
	 * @param STRING	key		A unique idenifer for the storage to pull from later
	 *
	 * Used to purge a specific key/value pair from the storage
	 */
	static removeLocalStorage(key) {
		chrome.storage.local.remove([key], () => {
			PCX.log(`Removed key: ${key}`);
		});
	}


/**
 * 
 * UI Interaction
 * 
 */

	/**
	 * getEl
	 * @param  STRING			selector	DOM Selector string
	 * @param  BOOL				requery		Ignore Cache and PCX.findEl()
	 * @return NODE|BOOL					Found: NODE | Missing: FALSE
	 *
	 * Wraps PCX.findEl() in a cache
	 * 
	 */
	static getEl(selector,requery=false) {
		if(!requery && PCX.pageElementsCache[selector]) {
			PCX.log(`PCX.getEl(${selector}) Cached`);
			return PCX.pageElementsCache[selector];
		} else {
			PCX.log(`PCX.getEl(${selector}) Requested`);
			return PCX.pageElementsCache[selector] = PCX.findEl(selector);
		}
	}

	/**
	 * getEls
	 * @param  STRING			selector	DOM Selector string
	 * @param  BOOL				requery		Ignore Cache and PCX.findEl()
	 * @return NODE|BOOL					Found: NODE | Missing: FALSE
	 *
	 * Wraps PCX.findEls() in a cache
	 * 
	 */
	static getEls(selector,requery=false) {
		if(!requery && PCX.pageElementsCache[selector]) {
			PCX.log(`PCX.getEls(${selector}) Cached`);
			return PCX.pageElementsCache[selector];
		} else {
			PCX.log(`PCX.getEls(${selector}) Requested`);
			return PCX.pageElementsCache[selector] = PCX.findEls(selector);
		}
	}

	/**
	 * findEl
	 * @param  STRING 		selector	DOM Selector string
	 * @return NODE|BOOL				Found: NODE | Missing: FALSE
	 *
	 * Call a fresh version of the selector
	 */
	static findEl(selector) {
		PCX.log(`PCX.findEl(${selector})`);
		return document.querySelector(selector);
	}

	/**
	 * findEls
	 * @param  STRING 		selector	DOM Selector string
	 * @return NODE|BOOL				Found: NODE | Missing: FALSE
	 *
	 * Call a fresh version of the selectors
	 */
	static findEls(selector) {
		PCX.log(`PCX.findEls(${selector})`);
		return document.querySelectorAll(selector);
	}

	static simulateUserKey(element, opts, type = 'keydown') {
		PCX.log(`PCX.simulateUserKey:`,element, opts);
		if (element && typeof opts == 'object') {
			let defaults = {bubbles: true, cancelable : false, key : "",shiftKey : false, keyCode: 0};
			let options = {...defaults,...opts};
			PCX.log(`PCX.simulateUserKey:`,options);

			let simKey = new KeyboardEvent(type, {bubbles: options.bubbles, cancelable: options.cancelable, key: options.key, shiftKey: options.shiftKey, keyCode: options.keyCode});
			element.dispatchEvent(simKey);
			PCX.log(`Simulated Key Press '${options.key}' on element: ${element.id}`);
			return true;
		} else {
			PCX.log(`Element not found: ${element.id}`);
			return false;
		}
	}

	static simulateUserInputValue(element, opts) {
		PCX.log(`PCX.simulateUserInputValue(${element})`);
		if (element && typeof opts == 'object') {
			let defaults = {bubbles: true, cancelable : false, key : "",shiftKey : false, keyCode: 0};
			let options = {...defaults,...opts};

			let simKey = new KeyboardEvent('keydown', {bubbles: options.bubbles, cancelable: options.cancelable, key: options.key, shiftKey: options.shiftKey, keyCode: options.keyCode});
			element.dispatchEvent(simKey);
			PCX.log(`Simulated Key Press '${options.key}' on element: ${element.id}`);
		} else {
			PCX.log(`Element not found: ${element.id}`);
		}
	}

	static simulateUserEvent(selector, eventName, arg=false) {
		let element = PCX.findEl(selector);
		if (element) {
			PCX.log(element);
			switch (eventName){
				case "focus":
					element.focus();
					// Ensure text selection or cursor is positioned
					if (element.setSelectionRange) {
						element.setSelectionRange(element.value.length, element.value.length); // Place cursor at the end
					} else {
						element.select(); // Select all text if preferred
					}
					break;
				case "value": //{value:'STRING',simInput:'BOOLEAN'} Value: Text to insert, simInput: Add KeyUp&Down
					if(!arg || typeof arg != 'object') {
						PCX.log(`Value is not defined`);
					}else{
						PCX.simulateUserInputValue(element, arg)
					}
					break;
				case "key":
					if(!arg) {
						PCX.log(`Key is not defined`);
					}else{
						PCX.simulateUserKey(element, arg)
					}
					break;
				default:
					let simEvent = new Event(eventName, { bubbles: true });
					element.dispatchEvent(simEvent);
					break;
			}
			PCX.log(`PCX.simulateUserEvent(${selector},${eventName}) Simulated`);
		} else {
			PCX.log(`PCX.simulateUserEvent(${selector}) Element not found`);
		}
	}


/**
 * 
 * Clipboard Operations
 * 
 */

	static copyToClipboard(text) {
		navigator.clipboard.writeText(text).then(
			() => PCX.log(`PCX.copyToClipboard(${text}) Success`),
			(err) => PCX.log(`PCX.copyToClipboard(${text}) Failed: ${err}`)
		);
	}

	static async readFromClipboard() {
		try {
			let text = await navigator.clipboard.readText();
			PCX.log(`PCX.readFromClipboard() Success: ${text}`)
			return text;
		} catch (err) {
			PCX.log(`PCX.readFromClipboard() Failed: ${err}`)
		}
	}


/**
 * 
 * Chrome Notifications
 * 
 */

	static ChromeNotification(title, message, id, remindTime = 0) {
		//if(chrome.runtime.id == undefined) return;
		chrome.runtime.sendMessage({
			action: "setNotification",
			title: title,
			message: message,
			notifId: id,
			remindTime: remindTime
		}, (response) => {
			PCX.log("Chrome notification response: " + response.status);
		});
	}

	static clearChromeNotificationReminder(id) {
		//if(chrome.runtime.id == undefined) return;
		chrome.runtime.sendMessage({
			action: "clearReminder",
			notifId: id
		}, (response) => {
			PCX.log("Cleared reminder for Chrome notification ID: " + id);
		});
	}

/**
 * 
 * Basic Notification Template
 * 
 */
	
	static showGUIModalNotification(title, message, id, remindTime = 0) {
		// Load external CSS file
		if (!PCX.findEl("#pcx-modal-style")) {
			//if(chrome.runtime.id == undefined) return;
			const link = PCX.createDOM("link", {id: "pcx-modal-style", rel: "stylesheet", href: chrome.runtime.getURL("css/modal.css")});
			document.head.appendChild(link);
		}

		if (!PCX.findEl("#pcx-modal-container")) {
			const modalContainer	= PCX.createDOM("div",	{ id: "pcx-modal-container"});
			  const modal			= PCX.createDOM("div",	{ id: "pcx-modal"});
				const modalTitle		= PCX.createDOM("h2",	{ textContent: title });
				const modalMessage		= PCX.createDOM("p",	{ innerHTML: message });
				const buttonContainer	= PCX.createDOM("div", 		{ id: "pcx-modal-buttons" });
					const okButton		= PCX.createDOM("button",	{ textContent: "OK", onclick: ()=>{
						document.body.removeChild(modalContainer);
						PCX.log("Modal dismissed");
					}});

			modal.appendChild(modalTitle);
			modal.appendChild(modalMessage);
			modal.appendChild(buttonContainer);

			buttonContainer.appendChild(okButton);

			if (remindTime > 0) {
				const remindButton = PCX.createDOM("button", {textContent: `Don't remind me for ${remindTime} hours`, onclick: ()=>{
					PCX.setLocalStorage("pcxid_" + id, Date.now() + remindTime * 3600000);
					document.body.removeChild(modalContainer);
					PCX.log(`User selected to not be reminded for ${remindTime} hours`);
				}});
				buttonContainer.appendChild(remindButton);
			}

			modalContainer.appendChild(modal);
			document.body.appendChild(modalContainer);
		}
	}

/********************************************
*
* Import Patient Data from Local Temp Cache.
*
* Notice Controller
*
*********************************************/
	static patientTransfer = {
		Notice	: "noticeDisplay",
		Info	: "patientInfo",
		Timer	: "patientDataTimer",
		Buffer	: 10
	}
	static notice = PCX.createDOM('div', {id: PCX.patientTransfer.Notice});
	static initializeNotice(patientData,callback=()=>{return;}) {
		PCX.notice.innerHTML = "";
		
		PCX.CategoryTranslation = {
			 3:"PGX",
			 4:"CGX",
			11:"Immuno",
			12:"Neuro"
		};
		// Left side: Patient details
		const patientInfo = PCX.createDOM('span', {
			id: 			PCX.patientTransfer.Info,
			textContent: 	`Patient: ${patientData.LastName}, ${patientData.FirstName} | ${PCX.CategoryTranslation[patientData.Category]}`
		});
			patientInfo.dataset.hash = PCX.hashCode(`${patientData.LastName}${patientData.FirstName}${patientData.Category}`)

		// Right side: Countdown timer
		const timer = PCX.createDOM('span', {id: PCX.patientTransfer.Timer, textContent: "-:--"})

		PCX.notice.appendChild(patientInfo);
		PCX.notice.appendChild(timer);
		document.body.appendChild(PCX.notice);
	}

	static async noticeUpdate(callback=()=>{return;}) {
		/*
		
		patientData: {
			FirstName:	patientData.FirstName,
			LastName:	patientData.LastName,
			Category:	patientData.Category
		}

		 */
		(new Promise(async resolve => {
			await chrome.storage.local.get(['patientData'], ( patientData ) => {
				PCX.patientData = patientData.patientData;
			});
			await chrome.storage.local.get(['noticeTimerState'], ( noticeTimerState ) => {
				PCX.patientTimer = noticeTimerState.noticeTimerState;
				return resolve()
			});
		})).then((resolve)=>{
			console.log('PCX.patientData: ',PCX.patientData);
			console.log('PCX.patientTimer: ',PCX.patientTimer);
			if(PCX.getEl(`#${PCX.patientTransfer.Notice}`,true) && PCX.patientTimer < PCX.patientTransfer.Buffer) {
				PCX.getEl(`#${PCX.patientTransfer.Notice}`).remove();
				return;
			}

			if(!PCX.getEl(`#${PCX.patientTransfer.Notice}`)) {
				PCX.initializeNotice(PCX.patientData,callback);
			}
			
			PCX.updateCountdownNotice = setInterval(async ()=>{
				PCX.patientTimer--;
				if(PCX.getEl(`#${PCX.patientTransfer.Notice}`,true) && PCX.patientTimer < PCX.patientTransfer.Buffer) {
					PCX.getEl(`#${PCX.patientTransfer.Notice}`).remove();
					return;
				}
				if (PCX.getEl(`#${PCX.patientTransfer.Timer}`,true)) {
					const minutes = Math.floor((PCX.patientTimer - PCX.patientTransfer.Buffer) / 60 );
					let seconds = ((PCX.patientTimer - PCX.patientTransfer.Buffer) % 60);
					PCX.getEl(`#${PCX.patientTransfer.Timer}`).textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
				}
			}, 1000);

			const hashCode = PCX.hashCode(`${PCX.patientData.LastName}${PCX.patientData.FirstName}${PCX.patientData.Category}`);
			if (PCX.getEl(`#${PCX.patientTransfer.Info}`,true).dataset.hash !== hashCode) {
				PCX.getEl(`#${PCX.patientTransfer.Info}`).dataset.hash = hashCode;
				PCX.getEl(`#${PCX.patientTransfer.Info}`).textContent = `Patient: ${PCX.patientData.LastName}, ${PCX.patientData.FirstName} | ${PCX.CategoryTranslation[PCX.patientData.Category]}`;
			}
			if (callback) {callback(PCX.patientData);}
		})
	}



/**
 * 
 * State and Navigation
 * 
 */
	static getUrlParams() {
		const params = {};
		const queryString = window.location.search;

		if (queryString) {
			const urlParams = new URLSearchParams(queryString);
			urlParams.forEach((value, key) => {
				params[key] = value;
			});
		}

		return params;
	}
	static getUrlDirectory() {
		return window.location.pathname.split('/');
	}

	static processEnabled(processID,overrider = false) {
		return PCX.getLocalStorage(processID, (result)=>{return result;});
	}


/**
 * 
 * Tools
 * 
 */
	/**
	 * currentUser
	 * @return STRING/BOOL
	 */
	static async currentUser() {
		if (PCX.currentUser) { return PCX.currentUser;}
		if(!PCX.getEl('.userName',true)){
			if(PCX.getUrlDirectory().pop() == "Pupup.aspx") {
				console.log('Pupup.aspx');
				PCX.currentUser = await chrome.storage.local.get('currentUser',
					data =>{
						console.log("data: ",data);
						return data.currentUser;
					}
				);
			}
			console.log('Unknown');
			return "";
		}
		console.log('standard');
		PCX.currentUser = PCX.getEl('.userName').textContent.replace('Welcome ','').replace(' ','');
		PCX.setLocalStorage('currentUser',PCX.currentUser);
		return PCX.currentUser;
	}

	/**
	 * mergeOptsIntoDefaults
	 * @param  OBJ	defaults	Preset Values
	 * @param  OBJ	opts		Overrides
	 * @return OBJ				Merged Object
	 *
	 * PCX.mergeOptsIntoDefaults(defaults,opts);
	 */
	static mergeOptsIntoDefaults(defaults,opts) {
		return [defaults,opts].reduce((result, item) => {
			if (typeof item === 'object' && item !== null) {
				result.push(Object.assign({}, ...result.filter(x => typeof x === 'object' && x !== null), item));
			} else {
				result.push(item);
			}
			return result;
		}, []);
	}

	static log(message) {
		if (PCX.getUrlParams()['debug']==true) {
			console.log(message);
		}
	}

	static hashCode(string) {
	  var hash = 0,
	    i, chr;
	  if (string.length === 0) return hash;
	  for (i = 0; i < string.length; i++) {
	    chr = string.charCodeAt(i);
	    hash = ((hash << 5) - hash) + chr;
	    hash |= 0; // Convert to 32bit integer
	  }
	  return hash;
	}

	static disableTabIndex(elements,iframe="") {
		elements.forEach((selector) => {
			if(iframe!="") {
				PCX.getEl(iframe).contentWindow.document.querySelector(selector).setAttribute("tabindex","-1");
			} else {
				PCX.getEl(selector).setAttribute("tabindex","-1");
			}
		});
	}

	static createDOM(domType, properties={}) {
		return Object.assign(document.createElement(domType), properties);
	}
	
}

// Expose PCX to the window
window.PCX = PCX;


/********************************************
*
* Wait for DOM Elements to exist before
* taking an action
* 
* DOM Observer
*
* Usage:
* waitForElm(selector).then(()=>{})
* waitForIframeElm(selector).then(()=>{})
*
*********************************************/
function waitForElm(selector) {
	return new Promise(resolve => {
		if (document.querySelector(selector)) {
			return resolve(document.querySelector(selector));
		}

		const observer = new MutationObserver(mutations => {
			if (document.querySelector(selector)) {
				observer.disconnect();
				resolve(document.querySelector(selector));
			}
		});

		// If you get "parameter 1 is not of type 'Node'" error, see https://stackoverflow.com/a/77855838/492336
		observer.observe(document.body, {
			childList: true,
			subtree: true
		});
	});
}
function waitForIframeElm(frame,selector) {
	return new Promise(resolve => {
		if (document.querySelector(frame).contentWindow.document.querySelector(selector)) {
			return resolve(document.querySelector(frame).contentWindow.document.querySelector(selector));
		}

		const observer = new MutationObserver(mutations => {
			if (document.querySelector(frame).contentWindow.document.querySelector(selector)) {
				observer.disconnect();
				resolve(document.querySelector(frame).contentWindow.document.querySelector(selector));
			}
		});

		// If you get "parameter 1 is not of type 'Node'" error, see https://stackoverflow.com/a/77855838/492336
		observer.observe(document.body, {
			childList: true,
			subtree: true
		});
	});
}
function waitForElmAfterChange(selector, root = document.body) {
	return new Promise(resolve => {
		const observer = new MutationObserver(() => {
			const el = document.querySelector(selector);
			if (el && el.isConnected) {
				observer.disconnect();
				resolve(el);
			}
		});

		observer.observe(root, {
			childList: true,
			subtree: true
		});
	});
}
function delay(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}
function ensureInputFocus(input) {
	if (!document.body.contains(input) || input.disabled || input.readOnly || input.offsetParent === null) {
		console.warn("Input is not focusable.");
		return false;
	}

	input.scrollIntoView({ behavior: 'smooth', block: 'center' });

	requestAnimationFrame(() => {
		input.focus();
		if (input.setSelectionRange) {
			const len = input.value.length;
			input.setSelectionRange(len, len);
		}
	});

	return true;
}