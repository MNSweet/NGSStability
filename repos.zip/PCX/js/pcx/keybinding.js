class Keybinding {
	constructor(bindings = {}) {
		this.bindings = bindings;
		this.initListener();
	}

	initListener() {
		document.addEventListener("keydown", (event) => {
			const key = event.code.toLowerCase().replace('key', '');
			const isShift	= event.shiftKey;
			const isAlt		= event.altKey;
			let bindingKey = `${key}`;
				bindingKey = `${isAlt ? "alt+" : ""}${bindingKey}`;
				bindingKey = `${isShift ? "shift+" : ""}${bindingKey}`;
			
			if (this.bindings[bindingKey]) {
				this.executeBinding(event,this.bindings[bindingKey]);
			}
		});
	}

	executeBinding(event,binding) {
		if (binding.type === "open") {
			event.preventDefault();
			this.requestOpenWindow(binding.target, binding.url, binding.whitelist);
		} else if (binding.type === "click") {
			event.preventDefault();
			this.clickElement(binding.selector);
		} else if (binding.type === "callback" && typeof binding.callback === "function") {
			binding.callback(event);
		}
	}

	requestOpenWindow(target, url, whitelist) {
		// Send message to background.js to handle tab opening and focusing
		chrome.runtime.sendMessage({
			action: "openWindow",
			target: target,
			url: url,
			whitelist: whitelist
		});
	}

	clickElement(selector) {
		const element = document.querySelector(selector);
		if (element) { element.click(); }
	}
}