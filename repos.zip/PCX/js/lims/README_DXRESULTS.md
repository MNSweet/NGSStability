# DXRESULTS BASED LIMS
**[⇪ Up Directory](../../README.md)**

Currently used by: Principle Diagnostics


## Definitions
*WIP*