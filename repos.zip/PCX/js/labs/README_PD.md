# Principle Diagnostics
**[⇪ Up Directory](../../README.md)**

### LIMS
>[DXResults](../lims/README_DXRESULTS.md)

## Global Definitions