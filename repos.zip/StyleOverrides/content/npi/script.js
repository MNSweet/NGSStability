function waitForElementToLoad(selector, callback) {
	// Check if the element already exists
	if (document.querySelector(selector)) {
		callback();
		return;
	}

	// If not, set up a MutationObserver
	const observer = new MutationObserver((mutationsList, observer) => {
		// Iterate through the mutations to see if our element has been added
		for (const mutation of mutationsList) {
			if (mutation.type === 'childList') {
				if (document.querySelector(selector)) {
					callback();
					observer.disconnect(); // Stop observing once the element is found
					return;
				}
			}
		}
	});

	// Start observing the document body for changes in its children
	observer.observe(document.body, { childList: true, subtree: true });
}

function copyToClipboard(text) {
	navigator.clipboard.writeText(text)
}

function addCopyElement(location,text) {
	copyToClipboard(text);
}
function createCopyButton(targetElement, textToCopy) {
	const button = document.createElement('button');
	button.type = 'button';
	button.textContent = '⧉'; // Unicode icon for copy

	button.style.cursor = 'pointer';
	button.style.marginLeft = '0.5em';
	button.title = 'Copy to clipboard';

	button.addEventListener('click', () => {
		copyToClipboard(textToCopy).then(() => {
			// Optional feedback for success
			button.textContent = '✅';
			setTimeout(() => {
				button.textContent = '⧉';
			}, 1000);
		}).catch(err => {
			console.error('Copy failed:', err);
			button.textContent = '❌';
			setTimeout(() => {
				button.textContent = '⧉';
			}, 1000);
		});
	});

	targetElement.appendChild(button);
}

waitForElementToLoad(`[aria-label="Provider Details"]>tbody>tr`, () => {
	document.querySelectorAll(`[aria-label="Provider Details"]>tbody>tr`).forEach((tr)=>{
		tr.classList.add(tr.children[0].innerText.replaceAll(/\s|[^a-zA-Z]/ig,``));
	})
	init(".NPI>td:nth-child(2)");
});

const baseURL = "https://npiregistry.cms.hhs.gov/provider-view/";
function init(selector) {
	const c = document.querySelector(selector);
	if (!c) return;
	const i = document.createElement("input");
	i.type = "text";
	i.id = "npiReloadInput";
	const b = document.createElement("button");
	b.textContent = "Lookup";
	b.id = "npiReloadBtn";
	c.appendChild(i);
	c.appendChild(b);
	b.addEventListener("click", () => {
		const v = i.value.trim();
		if (v) {window.location.href = baseURL + encodeURIComponent(v);}
	});
	i.addEventListener("keydown", e => {
		if (e.key === "Enter") {b.click();}
	});
}

