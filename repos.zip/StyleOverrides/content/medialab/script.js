function waitForElementToLoad(selector, callback, doc = document) {
	if (doc.querySelector(selector)) {
		callback();
		return;
	}

	const observer = new MutationObserver((mutations, obs) => {
		if (doc.querySelector(selector)) {
			callback();
			obs.disconnect();
		}
	});

	observer.observe(doc.body, { childList: true, subtree: true });
}

function waitForElementInIframe(iframeSelector, targetSelector, callback) {
	const iframe = document.querySelector(iframeSelector);
	if (!iframe) {
		return;
	}

	const run = () => {
		const doc = iframe.contentDocument || iframe.contentWindow.document;
		if (doc && doc.body) {
			waitForElementToLoad(targetSelector, callback, doc);
		}
	};

	if (iframe.contentDocument.readyState === 'complete') {
		run();
	} else {
		iframe.addEventListener('load', run);
	}
}

function checkForMore(){
	if(document.querySelector('[id^="todo_iframe"]').contentWindow.document.querySelectorAll(`.pe-normal:not([style^="background-color"]) .dtr-control a`).length > 0){
		document.querySelector('[id^="todo_iframe"]').contentWindow.document.querySelector(`.pe-normal:not([style^="background-color"]) .dtr-control a`).click();
		waitForElementInIframe('[id^="popupModaliFrame"]', '#completeAction', (target) => {
				target.click('Element inside iframe loaded')
					.then(
						setTimeout(()=>{
							document.querySelector('[aria-modal="true"] button.close').click();
						},500)
					);
		})
	}
}




/* Examples
waitForElementInIframe('#myIframe', '.iframe-element', () => {
	console.log('Element inside iframe loaded');
});

waitForElementToLoad('.top-level-element', () => {
	console.log('Element in top document loaded');
});
*/