class ServiceWorker {
	static log(message) {
		if (ServiceWorker.options.debug) {
			console.log(message);
		}
	}
}