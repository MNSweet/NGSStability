export class ServiceWorker {
	static options = {
		debug: true,
		domains: {
			pl: "https://prince.iatserv.com/",
			rr: "https://reliable.iatserv.com/",
			pd: "https://pnc.dxresults.com/"
		}
	};

	static log(message) {
		if (ServiceWorker.options.debug) {
			console.log(message);
		}
	}

	static async handleTabUpdate(tabId, tabUrl) {
		if (!tabUrl || 
			(!tabUrl.startsWith(ServiceWorker.options.domains.pl) && 
			!tabUrl.startsWith(ServiceWorker.options.domains.rr) && 
			!tabUrl.startsWith(ServiceWorker.options.domains.pd))) {
			ServiceWorker.changeExtensionIcon(false);
		} else {
			ServiceWorker.changeExtensionIcon(true);
		}
	}

	static changeExtensionIcon(change = false) {
		chrome.action.setIcon({ path: {
			"16": change ? "../icons/alt-icon-16.png" : "../icons/default-icon-16.png",
			"48": change ? "../icons/alt-icon-48.png" : "../icons/default-icon-48.png",
			"128": change ? "../icons/alt-icon-128.png" : "../icons/default-icon-128.png"
		}});
	}
}