function fileDrop(target,targetSpan=false,scrollTo=false){
	let 	isDragging 	= false;
	const	el			= {};
			el.DropArea		= target;
			el.ScrollTo		= scrollTo ? scrollTo : el.DropArea;
			el.AcceptTypes	= el.DropArea+' input[type="file"]';
			el.TargetSpan	= targetSpan ? targetSpan : el.DropArea.parentNode;
	const 	dropArea	= document.querySelector(el.DropArea).closest('*');
	const 	acceptTypes = document.querySelector(el.AcceptTypes).getAttribute('accept').split(',');

	dropArea.addEventListener("dragover", (e) => {
		dropZoneKeepAlive(isDragging,e);
	});
	dropArea.addEventListener("dragleave", (e) => {
		dropZoneTimeOut(isDragging,e);
	});
	document.addEventListener("dragover", (e) => {
		dropZoneKeepAlive(isDragging,e);
	});
	window.addEventListener("dragleave", (e) => {
		dropZoneTimeOut(isDragging,e);
	});

	dropArea.addEventListener("drop", (e) => {
		isDragging = false;
		if (document.body.classList.contains('dropZoneKeepAlive')) {
			document.body.classList.remove('dropZoneKeepAlive');

			if(document.querySelector(el.TargetSpan).textContent == "Drop File"){
				document.querySelector(el.TargetSpan).textContent = "Choose File";
			}
		}
		if(e.dataTransfer.files.length > 0) {
			for (const [i, file] of Object.entries(e.dataTransfer.files)) {
				let fileExt = file.name.split('.').pop();
				let fileName = file.name.replace('.'+fileExt,'');
				document.querySelector(el.ScrollTo).scrollIntoView({ behavior: "instant", block: "end"});
				if (acceptTypes.findIndex(function (a) { return a.toLowerCase() == ('.' + fileExt).toLowerCase() }) == -1) {
					return; // File not accepted
				}
			};
		}
	});

	function dropZoneKeepAlive(isDragging, e) {
		isDragging = true;
		if (!document.body.classList.contains('dropZoneKeepAlive')) {
			document.body.classList.add('dropZoneKeepAlive');
			document.querySelector(el.TargetSpan).textContent = "Drop File";
		}
	}
	function dropZoneTimeOut(isDragging, e) {
		if (e.target === window || (e.clientX === 0 && e.clientY === 0)) {
			isDragging = false;
			if (document.body.classList.contains('dropZoneKeepAlive')) {
				document.body.classList.remove('dropZoneKeepAlive');
				document.querySelector(el.TargetSpan).textContent = "Choose File";
			}
		}
	}
}

if(document.querySelectorAll('#dvDocumentsList #uploadTable').length == 1){
	fileDrop("#dvDocumentsList #uploadTable","#dvDocumentsList #uploadTable .upload span","#dvFooter");
}

if(document.querySelectorAll('#dvResutEntry_ResultDocuments #uploadTable').length == 1){
	fileDrop("#dvResutEntry_ResultDocuments #uploadTable","#dvResutEntry_ResultDocuments .upload span","#dvFooter");
}
