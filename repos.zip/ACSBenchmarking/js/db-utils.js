// js/db-utils.js

/**
 * Filter out entries whose user+timestamp already exist in the database.
 * @param {Object[]} entries – New entries to de-duplicate.
 * @returns {Promise<Object[]>} Unique entries only.
 */
async function filterDuplicateEntries(entries) {
	// 1) Fetch all existing entries
	const existing = await getAllEntries(); // from db.js
	// 2) Build a set of keys: "user|ISOdatetime"
	const existingKeys = new Set(
								existing.map(e => `${e.EnteredBy}|${new Date(e.CreatedDateTime).toISOString()}`)
	);

	// 3) Filter the new entries, keeping only those that aren't in existingKeys
	const unique = [];
	entries.forEach(e => {
		const key = `${e.EnteredBy}|${e.CreatedDateTime.toISOString()}`;
		if (!existingKeys.has(key)) {
			existingKeys.add(key);
			unique.push(e);
		}
	});
	return unique;
}

/**
 * Compute & store one day’s per‑user raw & Tukey‑filtered averages
 * (Combined, TeleHealth, DocChase) in **ms** into 'dailyMetrics'.
 * keyPath: ["date","user"]
 *
 * @param {string} dateStr – ISO date "YYYY-MM-DD"
 * @returns {Promise<void>}
 */
async function storeDailyMetrics(dateStr) {
	let db    = await initDB();
	let all   = await getAllEntries();

	// 1) Only Interval entries for that date
	let recs  = all.filter(r =>
		r.Type === "Interval" &&
		r.CreatedDateTime.toISOString().slice(0,10) === dateStr
	);

	// 2) Bucket seconds by user & group
	let byUser = {};
	recs.forEach(r => {
		let u   = r.EnteredBy || "Unknown";
		let s   = durationStringToSeconds(r.Duration);
		if (!byUser[u]) byUser[u] = { all: [], tele: [], doc: [] };
		byUser[u].all.push(s);
		(r.Group==="TeleHealth"
			? byUser[u].tele
			: byUser[u].doc
		).push(s);
	});

	// 3) Write per-user metrics in ms
	let tx    = db.transaction("dailyMetrics","readwrite");
	let store = tx.objectStore("dailyMetrics");

	for (let user in byUser) {
		let A = byUser[user].all.sort((a,b)=>a-b),
			T = byUser[user].tele.sort((a,b)=>a-b),
			D = byUser[user].doc .sort((a,b)=>a+b);

		// helper: mean of array or null
		const mean = arr => arr.length
			? arr.reduce((a,b)=>a+b,0)/arr.length
			: null;

		// raw means in s
		let rawAll  = mean(A),
			rawTele = mean(T),
			rawDoc  = mean(D);

		// Tukey bounds & inliers
		let {lower:la,upper:ua} = getTukeyFences(A),
			{lower:lt,upper:ut} = getTukeyFences(T),
			{lower:ld,upper:ud} = getTukeyFences(D);

		let inAll  = A.filter(v=>v>=la&&v<=ua),
			inTele = T.filter(v=>v>=lt&&v<=ut),
			inDoc  = D.filter(v=>v>=ld&&v<=ud);

		let narAll  = mean(inAll)  ?? rawAll,
			narTele = mean(inTele) ?? rawTele,
			narDoc  = mean(inDoc)  ?? rawDoc;

		// multiply by 1000 → ms
		await store.put({
			date               : dateStr,
			user               : user,
			combinedRawMs      : rawAll  != null ? Math.round(rawAll*1000)  : null,
			combinedNarrowMs   : narAll  != null ? Math.round(narAll*1000)  : null,
			teleRawMs          : rawTele != null ? Math.round(rawTele*1000) : null,
			teleNarrowMs       : narTele != null ? Math.round(narTele*1000) : null,
			docRawMs           : rawDoc  != null ? Math.round(rawDoc*1000)  : null,
			docNarrowMs        : narDoc  != null ? Math.round(narDoc*1000)  : null
		});
	}

	await tx.done;
}

/**
 * Completely clear out the dailyMetrics store.
 * @returns {Promise<void>}
 */
async function clearAllDailyMetrics() {
	let db = await initDB();
	let tx = db.transaction("dailyMetrics","readwrite");
	await tx.objectStore("dailyMetrics").clear();
	await tx.done;
}

/**
 * Recompute & store dailyMetrics for every date already in accessionDB.
 * @returns {Promise<void>}
 */
async function reprocessAllDailyMetrics() {
	// 1) Pull all accessions
	let all = await getAllEntries();

	// 2) Extract unique ISO‑dates
	let dates = [...new Set(
		all.map(r => r.CreatedDateTime.toISOString().split("T")[0])
	)];

	// 3) Optionally clear old cache
	await clearAllDailyMetrics();

	// 4) Re‑store metrics for each date
	for (let dateStr of dates) {
		await storeDailyMetrics(dateStr);
	}
}

/**
 * Retrieve every record in dailyMetrics (composite keys [date,user]).
 * @returns {Promise<Array>} Array of {date,user,combinedNarrowMs,teleNarrowMs,docNarrowMs,…}
 */
async function getAllDailyMetrics() {
	let db    = await initDB();
	let tx    = db.transaction("dailyMetrics","readonly");
	let store = tx.objectStore("dailyMetrics");
	return await store.getAll();
}