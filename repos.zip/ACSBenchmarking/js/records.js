// js/records.js

// ------------------
// GLOBAL STATE
// ------------------
let allRecordsForDay = []; // Array holding records for the currently selected day.
let currentSortField = null;
let currentSortDirection = 'asc';

// Global navigation state for the selected date.
let navigationState = {
	year: null,
	month: null,
	day: null
};

// Filter state object for each column.
let filterState = {
	Accession: { text: "" },
	Code: { text: "" },
	CreatedDateTime: { start: "00:00", end: "23:59" },
	Duration: { min: null, max: null },
	EnteredBy: { selected: new Set() },
	Group: { selected: new Set() },
	Type: { selected: new Set() }
};

// ------------------
// INITIALIZATION
// ------------------
document.addEventListener("DOMContentLoaded", () => {
	// Set up navigation controls (both above and below the table).
	initDateControls();

	// Sorting: attach click listeners to all sort icons.
	document.querySelectorAll(".sort-icon").forEach(icon => {
		icon.addEventListener("click", () => {
			const field = icon.dataset.field;
			toggleSort(field);
		});
	});

	// Filter: attach click listeners to filter icons to toggle popups.
	document.querySelectorAll(".filter-icon").forEach(icon => {
		icon.addEventListener("click", (e) => {
			e.stopPropagation(); // Prevent closing the popup immediately.
			const field = icon.dataset.field;
			toggleFilterPopup(field, icon.parentElement);
		});
	});

	// Close any open filter popups when clicking elsewhere.
	document.addEventListener("click", closeAllFilterPopups);

	// Prevent filter popups from closing when clicking inside.
	document.querySelectorAll(".filter-popup").forEach(popup => {
		popup.addEventListener("click", (evt) => evt.stopPropagation());
	});

	// Attach Apply and Clear button events inside each filter popup.
	document.querySelectorAll(".filter-popup").forEach(popup => {
		let applyBtn = popup.querySelector(".filter-apply-btn");
		if (applyBtn) applyBtn.addEventListener("click", () => applyFilter(popup.dataset.field));
		let clearBtn = popup.querySelector(".filter-clear-btn");
		if (clearBtn) clearBtn.addEventListener("click", () => clearFilter(popup.dataset.field));
	});

	// Navigation buttons (both navigation containers use these classes).
	document.querySelectorAll(".prev-day-btn").forEach(btn => btn.addEventListener("click", goToPreviousDay));
	document.querySelectorAll(".next-day-btn").forEach(btn => btn.addEventListener("click", goToNextDay));

	// Attach change events for all navigation select elements so that when any change, we update the global state.
	document.querySelectorAll(".month-select, .day-select, .year-select").forEach(select => {
		select.addEventListener("change", () => {
			updateNavigationStateFromDOM();
			updateAllNavigationControls();
			loadSelectedDay();
		});
	});
});

// ------------------
// FILTER POPUP FUNCTIONS
// ------------------
function toggleFilterPopup(field, thElement) {
	closeAllFilterPopups();
	const popup = thElement.querySelector(`.filter-popup[data-field="${field}"]`);
	if (popup) {
		popup.style.display = (popup.style.display === "block") ? "none" : "block";
	}
}
function closeAllFilterPopups() {
	document.querySelectorAll(".filter-popup").forEach(p => {
		p.style.display = "none";
	});
}

// ------------------
// APPLY FILTERS & SORTING
// ------------------
function toggleSort(field) {
	if (currentSortField === field) {
		currentSortDirection = (currentSortDirection === 'asc') ? 'desc' : 'asc';
	} else {
		currentSortField = field;
		currentSortDirection = 'asc';
	}
	applyFiltersAndSort();
}

function applyFiltersAndSort() {
	let filtered = allRecordsForDay.slice();

	// Filter: Accession and Code (text match)
	if (filterState.Accession.text) {
		filtered = filtered.filter(rec =>
			String(rec.Accession).toLowerCase().includes(filterState.Accession.text)
		);
	}
	if (filterState.Code.text) {
		filtered = filtered.filter(rec =>
			String(rec.Code).toLowerCase().includes(filterState.Code.text)
		);
	}
	// Filter: CreatedDateTime (time range)
	filtered = filtered.filter(rec => {
		if (rec.CreatedDateTime) {
			const createdDate = new Date(rec.CreatedDateTime);
			const [stH, stM] = filterState.CreatedDateTime.start.split(":").map(n => parseInt(n, 10));
			const [enH, enM] = filterState.CreatedDateTime.end.split(":").map(n => parseInt(n, 10));
			const dayStart = new Date(createdDate);
			dayStart.setHours(stH, stM, 0, 0);
			const dayEnd = new Date(createdDate);
			dayEnd.setHours(enH, enM, 59, 999);
			return createdDate >= dayStart && createdDate <= dayEnd;
		}
		return true;
	});
	// Filter: Duration (min/max in minutes)
	filtered = filtered.filter(rec => {
		if (rec.Duration) {
			const parts = rec.Duration.split(":").map(x => parseInt(x, 10));
			const totalMins = parts[0] * 60 + parts[1] + parts[2] / 60;
			if (filterState.Duration.min !== null && totalMins < filterState.Duration.min) return false;
			if (filterState.Duration.max !== null && totalMins > filterState.Duration.max) return false;
		}
		return true;
	});
	// Filter: Multi-select for EnteredBy, Group, and Type.
	if (filterState.EnteredBy.selected.size > 0) {
		filtered = filtered.filter(rec => filterState.EnteredBy.selected.has(rec.EnteredBy));
	}
	if (filterState.Group.selected.size > 0) {
		filtered = filtered.filter(rec => filterState.Group.selected.has(rec.Group));
	}
	if (filterState.Type.selected.size > 0) {
		filtered = filtered.filter(rec => filterState.Type.selected.has(rec.Type));
	}
	// Sorting
	if (currentSortField) {
		filtered.sort((a, b) => {
			let valA = a[currentSortField];
			let valB = b[currentSortField];
			if (currentSortField === "CreatedDateTime") {
				valA = new Date(valA).getTime();
				valB = new Date(valB).getTime();
			} else if (currentSortField === "Duration") {
				valA = valA ? valA.split(":").reduce((acc, curr, idx) => acc + parseInt(curr, 10) * [3600, 60, 1][idx], 0) : 0;
				valB = valB ? valB.split(":").reduce((acc, curr, idx) => acc + parseInt(curr, 10) * [3600, 60, 1][idx], 0) : 0;
			} else {
				valA = String(valA).toLowerCase();
				valB = String(valB).toLowerCase();
			}
			if (valA < valB) return currentSortDirection === 'asc' ? -1 : 1;
			if (valA > valB) return currentSortDirection === 'asc' ? 1 : -1;
			return 0;
		});
	}

	renderTable(filtered);
	updateSortIcons();
}

function updateSortIcons() {
	document.querySelectorAll(".sort-icon").forEach(icon => {
		icon.classList.remove("sort-asc", "sort-desc");
		if (icon.dataset.field === currentSortField) {
			icon.classList.add(currentSortDirection === 'asc' ? "sort-asc" : "sort-desc");
		}
	});
}

// ------------------
// FILTER FUNCTIONS
// ------------------
function applyFilter(field) {
	const popup = document.querySelector(`.filter-popup[data-field="${field}"]`);
	if (!popup) return;
	if (field === "Accession" || field === "Code") {
		const inputEl = popup.querySelector("input[type='text']");
		filterState[field].text = inputEl.value.trim().toLowerCase();
	} else if (field === "CreatedDateTime") {
		const startEl = popup.querySelector(".filter-created-start");
		const endEl = popup.querySelector(".filter-created-end");
		filterState[field].start = startEl.value;
		filterState[field].end = endEl.value;
	} else if (field === "Duration") {
		const minEl = popup.querySelector(".filter-duration-min");
		const maxEl = popup.querySelector(".filter-duration-max");
		filterState[field].min = minEl.value ? parseInt(minEl.value, 10) : null;
		filterState[field].max = maxEl.value ? parseInt(maxEl.value, 10) : null;
	} else if (field === "EnteredBy" || field === "Group" || field === "Type") {
		const selected = new Set();
		popup.querySelectorAll(".checkbox-list input[type='checkbox']").forEach(chk => {
			if (chk.checked) selected.add(chk.value);
		});
		filterState[field].selected = selected;
	}
	applyFiltersAndSort();
	closeAllFilterPopups();
}
function clearFilter(field) {
	if (field === "Accession" || field === "Code") {
		filterState[field].text = "";
	} else if (field === "CreatedDateTime") {
		filterState[field].start = "00:00";
		filterState[field].end = "23:59";
	} else if (field === "Duration") {
		filterState[field].min = null;
		filterState[field].max = null;
	} else if (field === "EnteredBy" || field === "Group" || field === "Type") {
		filterState[field].selected = new Set();
	}
	const popup = document.querySelector(`.filter-popup[data-field="${field}"]`);
	if (popup) {
		if (field === "Accession" || field === "Code") {
			popup.querySelector("input[type='text']").value = "";
		} else if (field === "CreatedDateTime") {
			popup.querySelector(".filter-created-start").value = "00:00";
			popup.querySelector(".filter-created-end").value = "23:59";
		} else if (field === "Duration") {
			popup.querySelector(".filter-duration-min").value = "";
			popup.querySelector(".filter-duration-max").value = "";
		} else {
			popup.querySelectorAll(".checkbox-list input[type='checkbox']").forEach(chk => {
				chk.checked = false;
			});
		}
	}
	applyFiltersAndSort();
	closeAllFilterPopups();
}

// ------------------
// RENDER TABLE
// ------------------
function renderTable(records) {
	const tbody = document.querySelector("#records-table tbody");
	tbody.innerHTML = "";
	records.forEach(entry => {
		const tr = document.createElement("tr");
		tr.innerHTML = `
			<td>${entry.Accession || ""}</td>
			<td>${entry.Code || ""}</td>
			<td>${entry.CreatedDateTime ? new Date(entry.CreatedDateTime).toLocaleString() : ""}</td>
			<td>${entry.Duration || "00:00:00"}</td>
			<td>${entry.EnteredBy || ""}</td>
			<td>${entry.Group || ""}</td>
			<td>${entry.Type || ""}</td>
		`;
		tbody.appendChild(tr);
	});
}

// ------------------
// NAVIGATION FUNCTIONS
// ------------------
// Initialize navigation controls in all containers.
function initDateControls() {
	const navContainers = document.querySelectorAll(".navigation-container");
	navContainers.forEach(container => {
		const monthSelect = container.querySelector(".month-select");
		const daySelect   = container.querySelector(".day-select");
		const yearSelect  = container.querySelector(".year-select");

		// Populate years (2020-2030).
		for (let y = 2020; y <= 2030; y++) {
			const opt = document.createElement("option");
			opt.value = y;
			opt.textContent = y;
			yearSelect.appendChild(opt);
		}
		// Populate months (1-12).
		for (let m = 1; m <= 12; m++) {
			const opt = document.createElement("option");
			opt.value = m;
			opt.textContent = m;
			monthSelect.appendChild(opt);
		}
		// Populate days (initially 1-31; will be updated).
		for (let d = 1; d <= 31; d++) {
			const opt = document.createElement("option");
			opt.value = d;
			opt.textContent = d;
			daySelect.appendChild(opt);
		}
	});

	// Set global navigationState to today.
	const now = new Date();
	navigationState.year = now.getFullYear();
	navigationState.month = now.getMonth() + 1;
	navigationState.day = now.getDate();

	updateAllNavigationControls();
	updateDaySelects();
	loadSelectedDay();
}

function updateAllNavigationControls() {
	document.querySelectorAll(".year-select").forEach(select => {
		select.value = navigationState.year;
	});
	document.querySelectorAll(".month-select").forEach(select => {
		select.value = navigationState.month;
	});
	updateDaySelects();
	document.querySelectorAll(".day-select").forEach(select => {
		select.value = navigationState.day;
	});
}

function updateDaySelects() {
	document.querySelectorAll(".navigation-container").forEach(container => {
		const month = parseInt(container.querySelector(".month-select").value, 10);
		const year = parseInt(container.querySelector(".year-select").value, 10);
		const daySelect = container.querySelector(".day-select");
		const daysInMonth = new Date(year, month, 0).getDate();
		let currentDay = parseInt(daySelect.value, 10) || 1;
		daySelect.innerHTML = "";
		for (let d = 1; d <= daysInMonth; d++) {
			const opt = document.createElement("option");
			opt.value = d;
			opt.textContent = d;
			daySelect.appendChild(opt);
		}
		if (currentDay > daysInMonth) currentDay = daysInMonth;
		daySelect.value = currentDay;
	});
}

async function loadSelectedDay() {
	const { year, month, day } = navigationState;
	// queryRecordsForExactDay is assumed to be defined in db.js.
	const records = await queryRecordsForExactDay(year, month, day);
	allRecordsForDay = records || [];
	// Build multi-select options for filter popups.
	buildMultiSelectOptions("EnteredBy", allRecordsForDay);
	buildMultiSelectOptions("Group", allRecordsForDay);
	buildMultiSelectOptions("Type", allRecordsForDay);
	applyFiltersAndSort();
}

function goToPreviousDay() {
	let dt = new Date(navigationState.year, navigationState.month - 1, navigationState.day);
	dt.setDate(dt.getDate() - 1);
	navigationState.year = dt.getFullYear();
	navigationState.month = dt.getMonth() + 1;
	navigationState.day = dt.getDate();
	updateAllNavigationControls();
	loadSelectedDay();
}

function goToNextDay() {
	let dt = new Date(navigationState.year, navigationState.month - 1, navigationState.day);
	dt.setDate(dt.getDate() + 1);
	navigationState.year = dt.getFullYear();
	navigationState.month = dt.getMonth() + 1;
	navigationState.day = dt.getDate();
	updateAllNavigationControls();
	loadSelectedDay();
}

// ------------------
// MULTI-SELECT FUNCTIONS
// ------------------
function buildMultiSelectOptions(field, records) {
	const uniqueValues = [...new Set(records.map(rec => rec[field]))].sort();
	const checklist = document.querySelector(`.filter-popup[data-field="${field}"] .checkbox-list`);
	if (!checklist) return;
	checklist.innerHTML = "";
	uniqueValues.forEach(val => {
		const id = `${field}-chk-${val}`;
		const div = document.createElement("div");
		div.innerHTML = `
			<input type="checkbox" id="${id}" value="${val}" checked>
			<label for="${id}">${val}</label>
		`;
		checklist.appendChild(div);
	});
	checklist.querySelectorAll("input[type='checkbox']").forEach(chk => {
		chk.addEventListener("change", () => applyFilter(field));
	});
}

function updateNavigationStateFromDOM() {
	const container = document.querySelector(".navigation-container");
	const yearSelect = container.querySelector(".year-select");
	const monthSelect = container.querySelector(".month-select");
	const daySelect = container.querySelector(".day-select");
	navigationState.year = parseInt(yearSelect.value, 10);
	navigationState.month = parseInt(monthSelect.value, 10);
	navigationState.day = parseInt(daySelect.value, 10);
}