// js/utils.js

/**
 * Parse a CSV date‑time string "DD/MM/YYYY HH:MM:SS AM/PM" → Date.
 * @param {string} dateTimeStr
 * @returns {Date}
 */
function parseDateTime(dateTimeStr) {
	const [datePart, timePart, period] = dateTimeStr.split(" ");
	const [day, month, year] = datePart.split("/");
	let [hours, minutes, seconds] = timePart.split(":").map(Number);
	if (period === "PM" && hours < 12) {
		hours += 12;
	} else if (period === "AM" && hours === 12) {
		hours = 0;
	}
	return new Date(year, month - 1, day, hours, minutes, seconds);
}

/**
 * Format a duration in seconds as "hh:mm:ss".
 * @param {number} seconds
 * @returns {string}
 */
function formatDuration(seconds) {
	const secNum = Math.floor(seconds);
	let hours = Math.floor(secNum / 3600);
	let minutes = Math.floor((secNum - hours * 3600) / 60);
	let secs = secNum - hours * 3600 - minutes * 60;
	hours = hours < 10 ? "0" + hours : hours;
	minutes = minutes < 10 ? "0" + minutes : minutes;
	secs = secs < 10 ? "0" + secs : secs;
	return `${hours}:${minutes}:${secs}`;
}

/**
 * Format total seconds as "M:SS" or "MM:SS".
 * @param {number} totalSeconds
 * @returns {string}
 */
function formatMinutesSeconds(totalSeconds) {
	const mins = Math.floor(totalSeconds / 60);
	const secs = Math.round(totalSeconds % 60);
	const secsStr = secs < 10 ? `0${secs}` : `${secs}`;
	return `${mins}:${secsStr}`;
}

/**
 * Convert a duration string "hh:mm:ss" → total seconds.
 * @param {string} durationStr
 * @returns {number}
 */
function durationStringToSeconds(durationStr) {
	const [h,m,s] = durationStr.split(":").map(Number);
	return h * 3600 + m * 60 + s;
}

/**
 * Given a sorted array of numbers, compute Tukey’s fences.
 * @param {number[]} sortedArray
 * @returns {{lower: number, upper: number}}
 */
function getTukeyFences(sorted) {
	const n = sorted.length;
	if (n < 4) return { lower: sorted[0], upper: sorted[n-1] };
	const interp = pos => {
		const idx = Math.floor(pos) - 1;
		const frac = pos - Math.floor(pos);
		return sorted[idx] + frac * (sorted[idx+1] - sorted[idx]);
	};
	const q1 = interp((n+1)/4);
	const q3 = interp(3*(n+1)/4);
	const iqr = q3 - q1;
	return { lower: q1 - 1.5*iqr, upper: q3 + 1.5*iqr };
}

/**
 * Retrieve precomputed dailyMetrics between two Date objects.
 * @param {Date} startDate
 * @param {Date} endDate
 * @returns {Promise<Object[]>}
 */
async function getDailyMetrics(startDate, endDate) {
	const db = await initDB();
	const tx = db.transaction("dailyMetrics", "readonly");
	const idx = tx.objectStore("dailyMetrics").index("date");
	const startKey = startDate.toISOString().split("T")[0];
	const endKey   = endDate.toISOString().split("T")[0];
	const range = IDBKeyRange.bound(startKey, endKey);
	return idx.getAll(range);
}

/**
 * Retrieve weekly metrics (Mon–Fri) containing the given weekStartDate.
 * @param {Date} weekStartDate
 * @returns {Promise<Object[]>}
 */
async function getWeeklyMetrics(weekStartDate) {
	const start = new Date(weekStartDate);
	const day = start.getDay();
	// Roll back to Monday if needed
	start.setDate(start.getDate() - ((day + 6) % 7));
	start.setHours(0,0,0,0);
	const end = new Date(start);
	end.setDate(start.getDate() + 4);
	end.setHours(23,59,59,999);
	return getDailyMetrics(start, end);
}

/**
 * Retrieve monthly metrics for the month of monthStartDate.
 * @param {Date} monthStartDate
 * @returns {Promise<Object[]>}
 */
async function getMonthlyMetrics(monthStartDate) {
	const start = new Date(monthStartDate.getFullYear(), monthStartDate.getMonth(), 1);
	start.setHours(0,0,0,0);
	const end = new Date(start.getFullYear(), start.getMonth()+1, 0);
	end.setHours(23,59,59,999);
	return getDailyMetrics(start, end);
}
