// js/charts.js

/**
 * Render a line chart with time‑axis formatting and padded min/max.
 * @param {string|CanvasRenderingContext2D} ctxOrId
 * @param {Object} chartData
 * @param {Object} [options]
 * @returns {Chart}
 */
function renderLineChart(ctxOrId, chartData, options = {}) {
	const ctx = typeof ctxOrId === "string"
	? document.getElementById(ctxOrId).getContext("2d")
	: ctxOrId;

	// Gather all data points (seconds)
	const allValues = chartData.datasets
	.flatMap(ds => ds.data)
	.filter(v => v != null && !isNaN(v));

	const dataMin = allValues.length ? Math.min(...allValues) : 0;
	const dataMax = allValues.length ? Math.max(...allValues) : 0;
	const pad = options.yPaddingSeconds ?? 30;
	const roundInterval = options.yStepSizeSeconds ?? 30;

	// Pad then round to nearest 30s
	const paddedMin = Math.max(0, dataMin - pad);
	const paddedMax = dataMax + pad;
	const yMin = (options.yMin !== undefined)
	? options.yMin
	: Math.floor(paddedMin / roundInterval) * roundInterval;
	const yMax = (options.yMax !== undefined)
	? options.yMax
	: Math.ceil(paddedMax / roundInterval) * roundInterval;

	return new Chart(ctx, {
		type: "line",
		data: chartData,
		options: {
			responsive: true,
			plugins: {
				legend: { display: false },
				tooltip: {
					mode: "index",
					intersect: false,
					callbacks: {
						label(ctx) {
							return `${ctx.dataset.label}: ${formatMinutesSeconds(ctx.parsed.y)}`;
						}
					}
				}
			},
			interaction: { mode: "nearest", axis: "x", intersect: false },
			scales: {
				x: { title: { display: true, text: options.xLabel || "Date" } },
				y: {
					title: { display: true, text: options.yLabel || "Time" },
					min: yMin,
					max: yMax,
					ticks: {
						stepSize: roundInterval,             // ← enforce 30‑sec steps
						callback: value => formatMinutesSeconds(value)
					}
				}
			},
			...options.chartOptions
		}
	});
}

/**
 * Build an interactive, grouped HTML legend under a Chart.js canvas.
 * @param {Chart} chart
 * @param {string} containerId
 */
function buildCustomLegend(chart, containerId) {
	const container = document.getElementById(containerId);
	container.innerHTML = "";

	const datasets = chart.data.datasets;
	const users = [...new Set(datasets.map(ds => ds.label.split(" (")[0]))];

	users.forEach(user => {
		const wrapper = document.createElement("div");
		wrapper.className = "legend-user";

		// Username label
		const name = document.createElement("span");
		name.className = "user-name";
		name.textContent = user + ":";
		wrapper.appendChild(name);

		// Helper to build a pill
		function makePill(groupName, type) {
			// Find the dataset index for this user & group
			const dsIndex = datasets.findIndex(ds =>
																				 ds.label.startsWith(user) && ds.label.includes(groupName)
																				 );
			if (dsIndex < 0) return null;

			const ds = datasets[dsIndex];
			const pill = document.createElement("span");
			pill.className = `legend-group ${type}`;
			pill.textContent = groupName;
			pill.style.color = ds.borderColor;
			pill.style.borderColor = ds.borderColor;

			// Initial disabled state?
			if (!chart.isDatasetVisible(dsIndex)) {
				pill.classList.add("disabled");
			}

			// On click: toggle visibility
			pill.addEventListener("click", () => {
				const currentlyVisible = chart.isDatasetVisible(dsIndex);
				chart.setDatasetVisibility(dsIndex, !currentlyVisible);
				chart.update();
				pill.classList.toggle("disabled", currentlyVisible);
			});

			return pill;
		}

		// TeleHealth pill
		const telePill = makePill("TeleHealth", "telehealth");
		if (telePill) wrapper.appendChild(telePill);

		// DocChase pill
		const docPill = makePill("DocChase", "docchase");
		if (docPill) wrapper.appendChild(docPill);

		container.appendChild(wrapper);
	});
}
