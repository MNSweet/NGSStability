// js/metrics-utils.js

const USER_COLORS = {
	"Alexa"       : "#f219ff",
	"Leeann Corvo": "#17b973",
	"Max Sweet"   : "#e59a10",
	"Joel Lima"   : "#0050a5"
};

/**
 * Load precomputed dailyMetrics from DB for a date range.
 * @param {string} startDate – “YYYY-MM-DD”
 * @param {string} endDate   – “YYYY-MM-DD”
 * @returns {Promise<Object[]>}
 */
async function loadMetricsForDateRange(startDate, endDate) {
	let metricsArr = await queryDailyMetrics(startDate, endDate);
	// Now merge/display these metrics as needed.
	console.log("Daily Metrics for range:", metricsArr);
	// You may update your UI accordingly.
}

/**
 * Build a dailyMetrics‑style array from raw Interval entries.
 * @param {Object[]} entries
 * @returns {Array}
 */
function computeDailyMetricsFromEntries(entries) {
	const map = {};
	entries
		.filter(r => r.Type === "Interval")
		.forEach(r => {
			const date = r.CreatedDateTime.toISOString().split("T")[0];
			const key  = date + "|" + r.EnteredBy;
			if (!map[key]) map[key] = { date, user: r.EnteredBy, tele: [], doc: [] };
			const secs = durationStringToSeconds(r.Duration);
			if (r.Group === "TeleHealth") map[key].tele.push(secs);
			else if (r.Group === "DocChase") map[key].doc.push(secs);
		});
	return Object.values(map).map(item => {
		const tele = item.tele.slice().sort((a,b)=>a-b);
		const doc  = item.doc.slice().sort((a,b)=>a-b);

		// compute Tukey fences
		const { lower: tLo, upper: tHi } = getTukeyFences(tele);
		const { lower: dLo, upper: dHi } = getTukeyFences(doc);

		const teleIn = tele.filter(v => v >= tLo && v <= tHi);
		const docIn  = doc .filter(v => v >= dLo && v <= dHi);

		const teleAvg = teleIn.length
		? teleIn.reduce((a,v)=>a+v,0)/teleIn.length
		: (tele.length ? tele.reduce((a,v)=>a+v,0)/tele.length : null);

		const docAvg  = docIn.length
		? docIn.reduce((a,v)=>a+v,0)/docIn.length
		: (doc.length ? doc.reduce((a,v)=>a+v,0)/doc.length : null);

		return {
		date:                item.date,
		user:                item.user,
		teleNarrowMs:  teleAvg,
		docNarrowMs:   docAvg
		};
	});
}

/**
 * Prepare Chart.js data for a weekly line chart.
 * @param {Array} dailyMetrics
 * @returns {{labels:string[],datasets:Object[]}}
 */
function computeWeeklyChartData(dailyMetrics) {
	console.log("computeWeeklyChartData",[dailyMetrics]);
	// X labels = sorted unique dates
	const labels = [...new Set(dailyMetrics.map(m => m.date))].sort();

	// Unique users
	const users = [...new Set(dailyMetrics.map(m => m.user))].sort();

	// Generate datasets: one solid (TeleHealth) and one dashed (DocChase) per user
	const palette = [
		"#1f77b4","#ff7f0e","#2ca02c","#d62728",
		"#9467bd","#8c564b","#e377c2","#7f7f7f",
		"#bcbd22","#17becf"
	];

	const datasets = users.flatMap((user, i) => {
		const color = USER_COLORS[user] || palette[i % palette.length];
		// TeleHealth series
		const teleData = labels.map(date => {
		const rec = dailyMetrics.find(r=>r.date===date && r.user===user);
		return (rec && rec.teleNarrowMs != null)
				? rec.teleNarrowMs / 1000
				: null;
		});
		// DocChase series
		const docData = labels.map(date => {
		const rec = dailyMetrics.find(r => r.date===date && r.user===user);
		return (rec && rec.docNarrowMs != null)
			? rec.docNarrowMs / 1000
			: null;
		});

		return [
			{
				label: `${user} (TeleHealth)`,
				data: teleData,
				borderColor: color,
				backgroundColor: color,
				borderWidth: 2,
				fill: false,
				borderDash: []
			},
			{
				label: `${user} (DocChase)`,
				data: docData,
				borderColor: color,
				backgroundColor: color,
				borderWidth: 2,
				fill: false,
				borderDash: [5,5]
			}
		];
	});

	return { labels, datasets };
}

/**
 * Prepare Chart.js data for a monthly line chart.
 * @param {Array} dailyMetrics
 * @returns {{labels:string[],datasets:Object[]}}
 */
function computeMonthlyChartData(dailyMetrics) {
	// 1. Derive only the dates for which you have data, sorted
	const labels = Array.from(
		new Set(dailyMetrics.map(m => m.date))
	).sort();

	// 2. Derive the unique users
	const users = [...new Set(dailyMetrics.map(m => m.user))].sort();

	// 3. Build datasets just as before, but mapping only over those labels
	const palette = [
		"#1f77b4","#ff7f0e","#2ca02c","#d62728",
		"#9467bd","#8c564b","#e377c2","#7f7f7f",
		"#bcbd22","#17becf"
	];

	const datasets = users.flatMap((user, i) => {
		// pick your color map or fallback to palette
		const baseColor = USER_COLORS[user] || palette[i % palette.length];

		// For each label (date), find that user’s record or null
		const teleData = labels.map(date => {
		const rec = dailyMetrics.find(r => r.date === date && r.user === user);
		return (rec && rec.teleNarrowMs != null)
			? rec.teleNarrowMs / 1000
			: null;
		});
		const docData = labels.map(date => {
		const rec = dailyMetrics.find(r => r.date === date && r.user === user);
		return (rec && rec.docNarrowMs != null)
			? rec.docNarrowMs / 1000
			: null;
		});

		return [
			{
				label: `${user} (TeleHealth)`,
				data: teleData,
				borderColor: baseColor,
				borderWidth: 2,
				fill: false,
				borderDash: []
			},
			{
				label: `${user} (DocChase)`,
				data: docData,
				borderColor: baseColor,
				borderWidth: 2,
				fill: false,
				borderDash: [5, 5]
			}
		];
	});

	return { labels, datasets };
}

/**
 * Renders a period‑over‑period delta table.
 *
 * @param {string} tbodyId  – the ID of the <tbody> to populate.
 * @param {Array}  rows     – array of delta objects from computeDeltaMetrics().
 * @param {Object} team     – aggregated team metrics from aggregateTeam().
 */
function renderDeltaTable(tbodyId, rows, team) {
	const tbody = document.getElementById(tbodyId);
	if (!tbody) return;
	tbody.innerHTML = "";

	// Format a time delta in seconds as "+M:SS" or "-M:SS"
	function formatDeltaTime(sec) {
		const abs  = Math.abs(sec);
		const str  = formatMinutesSeconds(abs);
		const emote = sec >= 0 ? (sec == 0 ? `` : `<span class="arrow arrowUp arrowRed">🔺<span>`) : `<span class="arrow arrowDown arrowGreen">🔻<span>`;
		return (sec >= 0 ? "+" : "-") + str + emote;
	}

	// Format a percent delta as "+X.X%" or "-X.X%"
	function formatDeltaPct(pct) {
		const sign = pct >= 0 ? "+" : "-";
		const emote = pct >= 0 ? (pct == 0 ? `` : `<span class="arrow arrowUp arrowGreen">🔺<span>`) : `<span class="arrow arrowDown arrowRed">🔻<span>`;
		return sign + Math.abs(pct).toFixed(1) + "%" + emote;
	}

	// One row per user
	rows.forEach(r => {
		const ov = r.overall;
		const th = r.tele;
		const dc = r.doc;

		const tr = document.createElement("tr");
		tr.innerHTML = `
			<td>${r.user}</td>
			<td class="metricsDeltaOverallColumn">${formatMinutesSeconds(ov.curr)}</td>
			<td class="metricsDeltaOverallColumn">${formatMinutesSeconds(ov.prev)}</td>
			<td class="metricsDeltaOverallColumn">${formatDeltaTime(ov.delta)}</td>
			<td class="metricsDeltaOverallColumn">${formatDeltaPct(ov.pct)}</td>
			<td class="metricsDeltaTeleHealthColumn">${formatMinutesSeconds(th.curr)}</td>
			<td class="metricsDeltaTeleHealthColumn">${formatMinutesSeconds(th.prev)}</td>
			<td class="metricsDeltaTeleHealthColumn">${formatDeltaTime(th.delta)}</td>
			<td class="metricsDeltaTeleHealthColumn">${formatDeltaPct(th.pct)}</td>
			<td class="metricsDeltaDocChaseColumn">${formatMinutesSeconds(dc.curr)}</td>
			<td class="metricsDeltaDocChaseColumn">${formatMinutesSeconds(dc.prev)}</td>
			<td class="metricsDeltaDocChaseColumn">${formatDeltaTime(dc.delta)}</td>
			<td class="metricsDeltaDocChaseColumn">${formatDeltaPct(dc.pct)}</td>
		`;
		tbody.appendChild(tr);
	});

	// Team summary row
	if (team) {
		const ov = team.overall;
		const th = team.tele;
		const dc = team.doc;

		const tr = document.createElement("tr");
		tr.classList.add("team-row");
		tr.innerHTML = `
			<td><strong>Team</strong></td>
			<td class="metricsDeltaOverallColumn"><strong>${formatMinutesSeconds(ov.curr)}</strong></td>
			<td class="metricsDeltaOverallColumn"><strong>${formatMinutesSeconds(ov.prev)}</strong></td>
			<td class="metricsDeltaOverallColumn"><strong>${formatDeltaTime(ov.delta)}</strong></td>
			<td class="metricsDeltaOverallColumn"><strong>${formatDeltaPct(ov.pct)}</strong></td>
			<td class="metricsDeltaTeleHealthColumn"><strong>${formatMinutesSeconds(th.curr)}</strong></td>
			<td class="metricsDeltaTeleHealthColumn"><strong>${formatMinutesSeconds(th.prev)}</strong></td>
			<td class="metricsDeltaTeleHealthColumn"><strong>${formatDeltaTime(th.delta)}</strong></td>
			<td class="metricsDeltaTeleHealthColumn"><strong>${formatDeltaPct(th.pct)}</strong></td>
			<td class="metricsDeltaDocChaseColumn"><strong>${formatMinutesSeconds(dc.curr)}</strong></td>
			<td class="metricsDeltaDocChaseColumn"><strong>${formatMinutesSeconds(dc.prev)}</strong></td>
			<td class="metricsDeltaDocChaseColumn"><strong>${formatDeltaTime(dc.delta)}</strong></td>
			<td class="metricsDeltaDocChaseColumn"><strong>${formatDeltaPct(dc.pct)}</strong></td>
		`;
		tbody.appendChild(tr);
	}
}

