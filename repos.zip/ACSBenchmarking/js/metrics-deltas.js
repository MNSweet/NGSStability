// js/metrics-deltas.js

/**
 * Compute Tukey‑filtered (“process”) average in seconds from Interval records.
 * @param {Object[]} records – Array with r.Duration and r.Type.
 * @returns {number}
 */
function computeNarrowAverageSeconds(records) {
	var secs = records
		.filter(function(r){ return r.Type === "Interval"; })
		.map(function(r){ return durationStringToSeconds(r.Duration); })
		.sort(function(a, b){ return a - b; });

	if (secs.length === 0) return 0;
	var n = secs.length;

	function interp(pos) {
		var idx  = Math.floor(pos) - 1;
		var frac = pos - Math.floor(pos);
		if (idx + 1 < n) {
			return secs[idx] + frac * (secs[idx+1] - secs[idx]);
		}
		return secs[idx];
	}

	var q1  = interp((n + 1) / 4);
	var q3  = interp(3 * (n + 1) / 4);
	var iqr = q3 - q1;
	var lower = q1 - 1.5 * iqr;
	var upper = q3 + 1.5 * iqr;

	var inliers = secs.filter(function(v){ return v >= lower && v <= upper; });
	if (inliers.length === 0) {
		return secs.reduce(function(a, v){ return a + v; }, 0) / n;
	}
	return inliers.reduce(function(a, v){ return a + v; }, 0) / inliers.length;
}

/**
 * Compute global raw average seconds for each group (TeleHealth/DocChase).
 * @param {Object[]} entries – All records.
 * @returns {{TeleHealth:number,DocChase:number}}
 */
function computeGroupGlobalAverageSeconds(entries) {
	var sums   = { TeleHealth: 0, DocChase: 0 };
	var counts = { TeleHealth: 0, DocChase: 0 };

	entries.forEach(function(r) {
		if (r.Type === "Interval") {
			var sec = durationStringToSeconds(r.Duration);
			sums[r.Group]   += sec;
			counts[r.Group] += 1;
		}
	});

	return {
		TeleHealth: counts.TeleHealth ? sums.TeleHealth / counts.TeleHealth : 0,
		DocChase:   counts.DocChase   ? sums.DocChase   / counts.DocChase   : 0
	};
}

/**
 * Compute period averages (in seconds) using dailyMetrics cache.
 * @param {Date} startDate
 * @param {Date} endDate
 */
async function computePeriodAverages(startDate, endDate) {
	// 1) Pull all per‑day/user metrics from store
	const startKey = startDate.toISOString().slice(0, 10);
	const endKey = endDate.toISOString().slice(0, 10);
	const raw = await queryDailyMetrics(startKey, endKey); // returns array of {date,user,combinedNarrowMs,...}

	// 2) Group by user
	const byUser = {};
	raw.forEach(r => {
		if (!byUser[r.user]) byUser[r.user] = { overallSec: [], teleSec: [], docSec: [] };
		// Add values for each group
		byUser[r.user].overallSec.push(r.combinedNarrowMs); // Overall
		if (r.teleNarrowMs != null) byUser[r.user].teleSec.push(r.teleNarrowMs); // TeleHealth
		if (r.docNarrowMs != null) byUser[r.user].docSec.push(r.docNarrowMs); // DocChase
	});

	// 3) Compute the mean of each user’s daily narrow values (ms → s)
	return Object.entries(byUser).map(([user, arr]) => {
		const meanOverallMs = arr.overallSec.reduce((a, b) => a + b, 0) / arr.overallSec.length;
		const meanTeleMs = arr.teleSec.reduce((a, b) => a + b, 0) / arr.teleSec.length;
		const meanDocMs = arr.docSec.reduce((a, b) => a + b, 0) / arr.docSec.length;

		// Convert ms to seconds and return
		return {
			user: user,
			overallSec: meanOverallMs / 1000, // Convert to seconds
			teleSec: meanTeleMs / 1000,       // Convert to seconds
			docSec: meanDocMs / 1000          // Convert to seconds
		};
	});
}


/**
 * Compute period‑over‑period deltas using process‑means.
 * @param {Date} currStart
 * @param {Date} currEnd
 * @param {Date} prevStart
 * @param {Date} prevEnd
 * @returns {Promise<Array<{user:string,overall:Object,tele:Object,doc:Object}>>}
 */
async function computeDeltaMetrics(currStart, currEnd, prevStart, prevEnd) {
	// Get current and previous period averages
	const curr = await computePeriodAverages(currStart, currEnd);
	const prev = await computePeriodAverages(prevStart, prevEnd);

	const prevMap = {};
	prev.forEach(p => prevMap[p.user] = p);

	return curr.map(c => {
		const p = prevMap[c.user] || { overallSec: 0, teleSec: 0, docSec: 0, recordCount: 0 };

		// Calculate the number of active days in the current and previous period
		const currDays = Math.ceil((currEnd - currStart) / (1000 * 60 * 60 * 24)); // Current days in period
		const prevDays = Math.ceil((prevEnd - prevStart) / (1000 * 60 * 60 * 24)); // Previous days in period

		// Get the number of records in the current and previous period
		const currRecordCount = c.recordCount || 0;  // Number of records for current period
		const prevRecordCount = p.recordCount || 0;  // Number of records for previous period

		// Scale the previous period's record count based on the number of days in the current period
		const scaleFactor = currDays / prevDays;

		// Scale previous period's record count
		const scaledPrevRecordCount = prevRecordCount * scaleFactor;

		// Calculate the delta for records and percentage
		const recordDelta = currRecordCount - scaledPrevRecordCount;
		const recordPctChange = prevRecordCount ? (recordDelta / prevRecordCount) * 100 : 0;

		// Function to compute deltas for time
		function makeObj(key, currentSec, prevSec) {
			const d = (currentSec - prevSec) || 0; // Ensure there's no NaN
			const pct = prevSec ? (d / prevSec) * 100 : 0;
			return { curr: currentSec || 0, prev: prevSec || 0, delta: d, pct: pct };
		}

		// Return deltas (time and record count)
		return {
			user: c.user,
			overall: makeObj("overall", c.overallSec, p.overallSec),
			tele: makeObj("tele", c.teleSec, p.teleSec),
			doc: makeObj("doc", c.docSec, p.docSec),
			recordCount: { curr: currRecordCount, prev: prevRecordCount, delta: recordDelta, pct: recordPctChange }
		};
	});
}


/**
 * Aggregate an array of delta rows into a single “Team” summary.
 * @param {Array} deltas
 * @returns {Object}
 */
function aggregateTeam(rows) {
	const team = {
		overall:{ curr:0,prev:0,delta:0,pct:0 },
		tele:   { curr:0,prev:0,delta:0,pct:0 },
		doc:    { curr:0,prev:0,delta:0,pct:0 }
	};
	rows.forEach(function(r) {
		["overall","tele","doc"].forEach(function(k) {
			team[k].curr  += r[k].curr;
			team[k].prev  += r[k].prev;
			team[k].delta += r[k].delta;
		});
	});

	// recompute team pct based on summed prev
	["overall","tele","doc"].forEach(function(k){
		team[k].pct = team[k].prev? (team[k].delta/team[k].prev)*100 / rows.length : 0;
		team[k].curr	= team[k].curr	/ rows.length;
		team[k].prev	= team[k].prev	/ rows.length;
		team[k].delta	= team[k].delta	/ rows.length;
	});

	return team;
}
