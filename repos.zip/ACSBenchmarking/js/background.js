// js/background.js
chrome.action.onClicked.addListener(() => {
	// Create a new tab loading your dashboard page from your extension package
	chrome.tabs.create({
		url: chrome.runtime.getURL("pages/dashboard.html")
	});
});
