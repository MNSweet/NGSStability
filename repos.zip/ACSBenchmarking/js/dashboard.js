// js/dashboard.js

/////////////////////////////////////////////////////////
// HELPER FUNCTIONS
/////////////////////////////////////////////////////////

/**
 * Parse raw PapaParse CSV rows into domain records.
 * 
 * Processes raw CSV data (an array of rows) into an array of record objects.
 * It looks for sub-header rows (e.g., "Entered By: ...") to set the current user.
 * Each data row should have an empty first cell, then: Accession, Code, DateTime.
 * Finally, it calls computeDurationsAndTypes() to calculate Duration and Type.
 * 
 * @param {Array[]} data
 * @returns {Object[]}
 */
function processCSVData(data) {
	let currentUser = "";
	let entries = [];
	data.forEach(row => {
		row = row.map(cell => cell.trim());
		if (!row.length) return;
		// Skip main header or summary rows.
		if (row[0] === "Accession" || row[0].match(/samples/i)) return;
		// Set current user if the row is a sub-header.
		if (row[0].startsWith("Entered By:")) {
			currentUser = row[0].replace("Entered By:", "").trim();
			return;
		}
		// Data rows: first cell is empty, then Accession, Code, DateTime.
		if (row[0] === "") {
			const [accession, code, dateTimeStr] = row.slice(1);
			if (!accession || !code || !dateTimeStr) return;
			// Determine group based on code prefix.
			let group = (code.startsWith("TS-") || code.startsWith("AM-") || code.startsWith("CTD-"))
				? "TeleHealth" : "DocChase";
			entries.push({
				Accession: accession,
				Code: code,
				CreatedDateTime: parseDateTime(dateTimeStr),
				EnteredBy: currentUser,
				Group: group
			});
		}
	});
	return computeDurationsAndTypes(entries);
}

/**
 * Compute Duration/Type fields on parsed records.
 * 
 * For each user, sorts the records by CreatedDateTime and computes the duration (in "hh:mm:ss")
 * between each consecutive record. The first record gets a Duration of "00:00:00" and Type "Start".
 * If the difference is more than 15 minutes (900 seconds), the record is marked "Break"; otherwise "Interval".
 *
 * @param {Object[]} entries
 * @returns {Object[]}
 */
function computeDurationsAndTypes(entries) {
	const groupsByUser = {};
	entries.forEach(entry => {
		if (!groupsByUser[entry.EnteredBy]) groupsByUser[entry.EnteredBy] = [];
		groupsByUser[entry.EnteredBy].push(entry);
	});
	Object.keys(groupsByUser).forEach(user => {
		const userEntries = groupsByUser[user].sort((a, b) => a.CreatedDateTime - b.CreatedDateTime);
		userEntries.forEach((entry, i) => {
			if (i === 0) {
				entry.Duration = "00:00:00";
				entry.Type = "Start";
			} else {
				const diffSeconds = (userEntries[i].CreatedDateTime - userEntries[i - 1].CreatedDateTime) / 1000;
				entry.Duration = formatDuration(diffSeconds);
				entry.Type = diffSeconds > 900 ? "Break" : "Interval";
			}
		});
	});
	return Object.values(groupsByUser).flat();
}


/////////////////////////////////////////////////////////
// DASHBOARD METRICS
/////////////////////////////////////////////////////////

/**
 * Compute and render the dashboard’s time‑average metrics.
 * 
 * Computes dashboard metrics by retrieving all entries from IndexedDB,
 * filtering for Interval records, grouping by user, and calculating:
 *  - Overall Interval Average (using the Duration field)
 *  - Per-group averages for each user.
 * Then updates the dashboard table.
 */
async function computeAndDisplayDashboardMetrics() {
	// 1) grab everything
	const allMetrics = await getAllDailyMetrics();  
	//    each item has date,user, combinedRawMs, combinedNarrowMs, teleRawMs, teleNarrowMs, docRawMs, docNarrowMs

	// 2) group by user
	const byUser = {};
	allMetrics.forEach(r => {
		(byUser[r.user] = byUser[r.user]||[]).push(r);
	});

	// 3) for each user, average across days (ms → sec)
	const rows = Object.entries(byUser).map(([user, recs]) => {
		const meanMs = arr => arr.reduce((a,b)=>a+b,0)/arr.length;

		// filter out nulls
		const cRawArr = recs.map(r=>r.combinedRawMs).filter(v=>v!=null);
		const cNarArr = recs.map(r=>r.combinedNarrowMs).filter(v=>v!=null);
		const tRawArr = recs.map(r=>r.teleRawMs).filter(v=>v!=null);
		const tNarArr = recs.map(r=>r.teleNarrowMs).filter(v=>v!=null);
		const dRawArr = recs.map(r=>r.docRawMs).filter(v=>v!=null);
		const dNarArr = recs.map(r=>r.docNarrowMs).filter(v=>v!=null);

		const cRawSec = cRawArr.length ? meanMs(cRawArr)/1000 : 0;
		const cNarSec = cNarArr.length ? meanMs(cNarArr)/1000 : 0;
		const tRawSec = tRawArr.length ? meanMs(tRawArr)/1000 : 0;
		const tNarSec = tNarArr.length ? meanMs(tNarArr)/1000 : 0;
		const dRawSec = dRawArr.length ? meanMs(dRawArr)/1000 : 0;
		const dNarSec = dNarArr.length ? meanMs(dNarArr)/1000 : 0;

		return {
			user,
			combined: { raw: cRawSec, nar: cNarSec },
			tele:     { raw: tRawSec, nar: tNarSec },
			doc:      { raw: dRawSec, nar: dNarSec }
		};
	});

	// 4) render
	const tbody = document.getElementById("dashboard-metrics-tbody");
	tbody.innerHTML = "";
	rows.forEach(m => {
		const tr = document.createElement("tr");
		tr.innerHTML = `
		  <td>${m.user}</td>
		  <td>${formatMinutesSeconds(m.combined.nar)} <small>(${formatMinutesSeconds(m.combined.raw)})</small></td>
		  <td>${formatMinutesSeconds(m.tele.nar)} <small>(${formatMinutesSeconds(m.tele.raw)})</small></td>
		  <td>${formatMinutesSeconds(m.doc.nar)} <small>(${formatMinutesSeconds(m.doc.raw)})</small></td>
		`;
		tbody.appendChild(tr);
	});
}

/**
 * For a given user’s Interval records, computes raw & narrow averages
 * per group (TeleHealth, DocChase).
 * Returns an object:
 * {
 *   TeleHealth: { raw: "M:SS", narrow: "M:SS" },
 *   DocChase:   { raw: "M:SS", narrow: "M:SS" }
 * }
 * 
 * @param {Object[]} records
 * @returns {{TeleHealth:Object,DocChase:Object}}
 */
function computeGroupAverages(records) {
	const groups = ["TeleHealth","DocChase"];
	const result = {};

	groups.forEach(grp => {
	// Extract seconds for Interval records of this group
	const secs = records
		.filter(r => r.Group === grp && r.Type === "Interval")
		.map(r => durationStringToSeconds(r.Duration))
		.sort((a, b) => a - b);

	if (!secs.length) {
		result[grp] = { raw: "0:00", narrow: "0:00" };
		return;
	}

	// Raw average
	const sum = secs.reduce((a, v) => a + v, 0);
	const rawAvgSec = sum / secs.length;

	// Tukey fences & narrow average
	const { lower, upper } = getTukeyFences(secs);
	const inliers = secs.filter(v => v >= lower && v <= upper);
	const narrowAvgSec = inliers.length
		? inliers.reduce((a, v) => a + v, 0) / inliers.length
		: rawAvgSec;

	result[grp] = {
		raw:    formatMinutesSeconds(rawAvgSec),
		narrow: formatMinutesSeconds(narrowAvgSec)
	};
	});

	return result;
}

/**
 * Main function to compute and display Daily Volume Processing by User per Day.
 * This function retrieves all entries from IndexedDB, computes daily volume stats,
 * finalizes average percentages per user, and updates the dashboard table.
 */
async function computeAndDisplayDailyVolumeByUser() {
	const entries = await getAllEntries();
	const userStats = computeDailyVolumeStats(entries);
	const volumeMetrics = finalizeDailyVolumeStats(userStats);
	const pcrPctByUser = computeWeeklyPCRPercentages(entries);

	volumeMetrics.forEach(m => {
	m.pcrPercent = pcrPctByUser[m.user] || "0.00";
	});

	updateDailyVolumeTable(volumeMetrics);
}

/**
 * Computes daily volume stats for each user based only on the overall totals.
 * For each day:
 *  - Skip the day if total accessions < 6.
 *  - Skip the day if any single user accounts for >80% of overall accessions.
 *  - For each user on that valid day, compute:
 *       dailyAccessPct = (user's accessions / dayTotal) * 100,
 *       dailyTelePct   = (user's TeleHealth accessions / dayTeleTotal) * 100 (if dayTeleTotal > 0; otherwise 0),
 *       dailyDocPct    = (user's DocChase accessions / dayDocTotal) * 100 (if dayDocTotal > 0; otherwise 0).
 * Then, for each user across all valid days, accumulate the percentages and count the days.
 *
 * @param {Array} records - Array of records.
 * @returns {Object} - An object mapping each user to their accumulated metrics and count of valid days.
 */
function computeDailyVolumeStats(records) {
	// Filter out records with code "5556" (PCR noise)
	const validRecords = records.filter(r => r.Code !== "5556");

	const groupedByDay = groupRecordsByDay(validRecords);
	// This will hold the accumulation of daily percentages for each user.
	// For each user, we'll accumulate:
	//   { dailyAccessSum, dailyTeleSum, dailyDocSum, dayCount }
	let userStats = {};

	Object.keys(groupedByDay).forEach(dayStr => {
	const dayRecords = groupedByDay[dayStr];

	const dayTotal = dayRecords.length;
	// Skip day if overall total is less than 6.
	if (dayTotal < 6) return;

	// Count overall for each user.
	let userCount = {};
	// Also count by group (TeleHealth and DocChase) on the day.
	let userTele = {};
	let userDoc  = {};

	// Overall group totals for the day.
	let dayTeleTotal = 0;
	let dayDocTotal = 0;

	dayRecords.forEach(rec => {
		const user = rec.EnteredBy || "Unknown";
		if (!userCount[user]) {
		userCount[user] = 0;
		userTele[user] = 0;
		userDoc[user] = 0;
		}
		userCount[user]++;
		// Increment overall dayTeleTotal or dayDocTotal if applicable.
		if (rec.Group === "TeleHealth") {
		userTele[user]++;
		dayTeleTotal++;
		} else if (rec.Group === "DocChase") {
		userDoc[user]++;
		dayDocTotal++;
		}
	});

	// Check the 80% threshold on overall dayTotal: if any user has more than 80% of dayTotal, skip the day.
	let skipDay = false;
	Object.keys(userCount).forEach(u => {
		if (userCount[u] > dayTotal * 0.8) skipDay = true;
	});
	if (skipDay) return;

	// For each user on this valid day, compute daily percentages.
	Object.keys(userCount).forEach(u => {
		const dailyAccessPct = (userCount[u] / dayTotal) * 100;
		// If no TeleHealth accessions for the day, set 0 instead of NaN.
		let dailyTelePct = dayTeleTotal > 0 ? (userTele[u] / dayTeleTotal) * 100 : 0;
		let dailyDocPct  = dayDocTotal > 0 ? (userDoc[u] / dayDocTotal) * 100 : 0;

		if (!userStats[u]) {
		userStats[u] = {
			dailyAccessSum: 0,
			dailyTeleSum: 0,
			dailyDocSum: 0,
			dayCount: 0
		};
		}
		userStats[u].dailyAccessSum += dailyAccessPct;
		userStats[u].dailyTeleSum += dailyTelePct;
		userStats[u].dailyDocSum  += dailyDocPct;
		userStats[u].dayCount++;
	});
	});

	return userStats;
}

/**
 * Groups records by day, keyed as "YYYY-MM-DD".
 * @param {Array} records - Array of records. Each record must have a CreatedDateTime property (a Date object).
 * @returns {Object} - Keys are day strings; values are arrays of records for that day.
 */
function groupRecordsByDay(records) {
	let grouped = {};
	records.forEach(rec => {
	const dayStr = rec.CreatedDateTime.toISOString().split("T")[0];
	if (!grouped[dayStr]) grouped[dayStr] = [];
	grouped[dayStr].push(rec);
	});
	return grouped;
}


/**
 * Finalizes the daily volume stats by computing average daily percentages for each user.
 * @param {Object} userStats - Output from computeDailyVolumeStats().
 * @returns {Array} - An array of objects, each with user, avgAccess, avgTele, avgDoc.
 */
function finalizeDailyVolumeStats(userStats) {
	let results = [];
	Object.keys(userStats).forEach(u => {
	const stats = userStats[u];
	if (stats.dayCount > 0) {
		const avgAccess = (stats.dailyAccessSum / stats.dayCount).toFixed(2);
		const avgTele   = (stats.dailyTeleSum / stats.dayCount).toFixed(2);
		const avgDoc    = (stats.dailyDocSum  / stats.dayCount).toFixed(2);
		results.push({
		user: u,
		avgAccess,
		avgTele,
		avgDoc
		});
	}
	});
	// Sort results by user name if desired.
	results.sort((a, b) => a.user.localeCompare(b.user));
	return results;
}

/**
 * Computes each user’s percentage share of PCR entries (Code === "5556")
 * for the current week (Sunday → Saturday).
 * @param {Array} records - All records (with CreatedDateTime and EnteredBy).
 * @returns {Object} - user → percentage (0–100, two decimals).
 */
function computeWeeklyPCRPercentages(records) {
	// 1) Determine this week’s Sunday (start) and Saturday (end).
	const today = new Date();
	const dayOfWeek = today.getDay(); // 0=Sunday
	const weekStart = new Date(today);
	weekStart.setDate(today.getDate() - dayOfWeek);
	weekStart.setHours(0,0,0,0);
	const weekEnd = new Date(weekStart);
	weekEnd.setDate(weekStart.getDate() + 6);
	weekEnd.setHours(23,59,59,999);

	// 2) Filter to PCR records in that range.
	const pcrRecs = records.filter(r => 
	r.Code === "5556" &&
	r.CreatedDateTime >= weekStart &&
	r.CreatedDateTime <= weekEnd
	);

	// 3) Count by user.
	const counts = {};
	pcrRecs.forEach(r => {
	const u = r.EnteredBy || "Unknown";
	counts[u] = (counts[u] || 0) + 1;
	});
	const total = pcrRecs.length;
	if (total === 0) {
	// No PCR this week → everyone gets 0%
	return Object.keys(counts).reduce((acc,u) => {
		acc[u] = "0.00"; return acc;
	}, {});
	}

	// 4) Compute percentage per user.
	const result = {};
	Object.keys(counts).forEach(u => {
	result[u] = ((counts[u] / total) * 100).toFixed(2);
	});
	return result;
}

/**
 * Updates the "Daily Volume Processing by User per Day" dashboard table.
 * Expects an element with ID "dashboard-volume-tbody" in the dashboard HTML.
 * @param {Array} volumeMetrics - Array of user metric objects.
 */
function updateDailyVolumeTable(volumeMetrics) {
	const tbody = document.getElementById("dashboard-volume-tbody");
	if (!tbody) return;
	tbody.innerHTML = "";
	volumeMetrics.forEach(m => {
	const tr = document.createElement("tr");
	tr.innerHTML = `
		<td>${m.user}</td>
		<td>${m.avgAccess}%</td>
		<td>${m.avgTele}%</td>
		<td>${m.avgDoc}%</td>
		<td>${m.pcrPercent}%</td>
	`;
	tbody.appendChild(tr);
	});
}

/////////////////////////////////////////////////////////
// CSV UPLOAD HANDLER
/////////////////////////////////////////////////////////

document.getElementById("upload-btn").addEventListener("click", () => {
	const fileInput = document.getElementById("csv-upload");
	if (!fileInput.files.length) {
	alert("Please select a CSV file first.");
	return;
	}
	const file = fileInput.files[0];
	Papa.parse(file, {
	complete: async function(results) {
		// 1) Parse & compute Duration/Type
		let entries = processCSVData(results.data);
		// 2) Filter out duplicates
		entries = await filterDuplicateEntries(entries);
		// 3) Store only the uniques
		for (const entry of entries) {
		await addEntry(entry);
		}
		document.getElementById("upload-status").innerText = `Parsed and saved ${entries.length} new entries.`;
		// 4) Refresh dashboards
		computeAndDisplayDashboardMetrics();
		computeAndDisplayDailyVolumeByUser();
		const dateStr = entries.length
			? entries[0].CreatedDateTime.toISOString().split("T")[0]
			: null;
		if (dateStr) {
			await storeDailyMetrics(dateStr);
		}
	}
	});
});

// Compute and display dashboard metrics on page load.
document.addEventListener("DOMContentLoaded", () => {
	computeAndDisplayDashboardMetrics();
	computeAndDisplayDailyVolumeByUser();
});