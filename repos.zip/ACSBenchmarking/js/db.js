// js/db.js

/**
 * Open (or upgrade) the IndexedDB database and return the database instance.
 * @returns {Promise<IDBPDatabase>} The open database.
 */
async function initDB() {
	// Bump the version to 3 so upgrade() fires
	let db = await openDB("accessionDB", 4, {
		upgrade(db, oldVersion, newVersion, transaction) {
			// accessions store (existing logic)
			if (!db.objectStoreNames.contains("accessions")) {
				const store = db.createObjectStore("accessions", { keyPath: "id", autoIncrement: true });
				store.createIndex("CreatedDateTime", "CreatedDateTime", { unique: false });
				store.createIndex("EnteredBy", "EnteredBy", { unique: false });
				store.createIndex("Group", "Group", { unique: false });
			} else {
				// If you later add new indexes to accessions, handle them here:
				const store = transaction.objectStore("accessions");
				if (!store.indexNames.contains("CreatedDateTime")) {
					store.createIndex("CreatedDateTime", "CreatedDateTime", { unique: false });
				}
				if (!store.indexNames.contains("EnteredBy")) {
					store.createIndex("EnteredBy", "EnteredBy", { unique: false });
				}
				if (!store.indexNames.contains("Group")) {
					store.createIndex("Group", "Group", { unique: false });
				}
			}

			// dailyMetrics store + date index
			if (db.objectStoreNames.contains("dailyMetrics")) {
				// remove old store so you can recreate it with a new keyPath
				db.deleteObjectStore("dailyMetrics");
			}
			// now recreate it with a composite keyPath [date,user]
			const dm = db.createObjectStore("dailyMetrics", {
				keyPath: ["date", "user"]
			});
			// keep an index on date so you can query ranges
			dm.createIndex("date", "date", { unique: false });

			// Future stores/indexes...
		}
	});
	return db;
}

/**
 * Add a single accession entry into the database.
 * @param {Object} entry – The record to add.
 * @returns {Promise<void>}
 */
async function addEntry(entry) {
	let db = await initDB();
	await db.add("accessions", entry);
}

/**
 * Retrieve all accession entries from the database.
 * @returns {Promise<Object[]>} Array of all records.
 */
async function getAllEntries() {
	let db = await initDB();
	return await db.getAll("accessions");
}

/**
 * Query accession records by a date range via the CreatedDateTime index.
 * @param {string} startDate – ISO date string “YYYY-MM-DD”.
 * @param {string} endDate   – ISO date string “YYYY-MM-DD”.
 * @returns {Promise<Object[]>} Array of matching records.
 */
async function queryRecordsByDateRange(startDate, endDate) {
	let db = await initDB();
	// Create Date objects from the start and end.
	let start = new Date(startDate);
	let end = new Date(endDate);
	// Create a range. Adjust the end to cover the full day if needed.
	let range = IDBKeyRange.bound(start, end);
	let tx = db.transaction("accessions", "readonly");
	let index = tx.objectStore("accessions").index("CreatedDateTime");
	return await index.getAll(range);
}

/**
 * Query stored daily metrics for a date range.
 * @param {string} startDate – “YYYY-MM-DD”.
 * @param {string} endDate   – “YYYY-MM-DD”.
 * @returns {Promise<Object[]>} Array of metrics records.
 */
async function queryDailyMetrics(startDate, endDate) {
	let db = await initDB();
	let tx = db.transaction("dailyMetrics", "readonly");
	let store = tx.objectStore("dailyMetrics");
	let allMetrics = await store.getAll();
	// Filter by date string. (You can adjust if you need a more robust date range query.)
	return allMetrics.filter(record => record.date >= startDate && record.date <= endDate);
}

/**
 * Retrieve all accession records for an exact day (year, month, day).
 * @param {number} year
 * @param {number} month – 1–12
 * @param {number} day   – 1–31
 * @returns {Promise<Object[]>} Array of that day’s records.
 */
async function queryRecordsForExactDay(year, month, day) {
	let db = await initDB();
	
	// Build the start/end date objects for that day.
	let start = new Date(year, month - 1, day, 0, 0, 0);
	let end = new Date(year, month - 1, day, 23, 59, 59, 999);
	
	let range = IDBKeyRange.bound(start, end);
	let tx = db.transaction("accessions", "readonly");
	let index = tx.objectStore("accessions").index("CreatedDateTime");
	let results = await index.getAll(range);
	return results;
}
