// js/metrics-init.js


/**
 * Initialize the Metrics page: charts & delta tables on DOMContentLoaded.
 */
document.addEventListener("DOMContentLoaded", function() {
	// --- Weekly Chart init ---
	const wkCanvas = document.getElementById("weeklyChart");
	const today = new Date();
	const dow = today.getDay();
	const weekStart = new Date(today);
	weekStart.setDate(today.getDate() - ((dow + 6) % 7));
	weekStart.setHours(0,0,0,0);

	getWeeklyMetrics(weekStart).then(async daily => {
		console.log("getWeeklyMetrics: ",daily);
		if (daily.length === 0) {
		// Fallback: build from raw entries
			const all = await getAllEntries();
			console.log("getWeeklyMetrics Fallback all: ",all);
			console.log("getWeeklyMetrics computeDailyMetricsFromEntries: ",computeDailyMetricsFromEntries(all).filter(m => m.date >= weekStart));
			daily = computeDailyMetricsFromEntries(all)
			.filter(m => m.date >= weekStart.toISOString().split("T")[0]);
		}
		const chartData = computeWeeklyChartData(daily);
		const weeklyChartInstance = renderLineChart(wkCanvas, chartData, { xLabel:"Mon→Fri", yLabel:"Time(Min:Sec)"});
		buildCustomLegend(weeklyChartInstance, "weeklyLegend");
	});

	// --- Monthly Chart init ---
	const moCanvas = document.getElementById("monthlyChart");
	const now = new Date();
	// First day of current month at midnight
	const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
	monthStart.setHours(0,0,0,0);
	// Last moment of current month
	const monthEnd = new Date(monthStart.getFullYear(), monthStart.getMonth() + 1, 0);
	monthEnd.setHours(23,59,59,999);

	getMonthlyMetrics(monthStart).then(async daily => {
		if (!daily.length) {
		// Fallback: compute dailyMetrics from raw Interval entries
			const all = await getAllEntries();
			daily = computeDailyMetricsFromEntries(all)
			.filter(m => m.date >= monthStart.toISOString().split("T")[0]
			        && m.date <= monthEnd  .toISOString().split("T")[0]);
		}
		const chartData = computeMonthlyChartData(daily);
		const monthlyChartInstance = renderLineChart(moCanvas, chartData, {
			xLabel: "Days of the Current Month with data",
			yLabel: "Time (Min:Sec)"
		});
		buildCustomLegend(monthlyChartInstance, "monthlyLegend");
	});
	
// Normalize “today” to midnight
	today.setHours(0, 0, 0, 0);

	//
	// ─── WEEK‑OVER‑WEEK ────────────────────────────────────────────────
	//
	// 1) Find this week’s Monday at 00:00
	const daysSinceMonday = (dow + 6) % 7;                // Mon→0, Tue→1…Sun→6
	const currMon = new Date(today);
	currMon.setDate(today.getDate() - daysSinceMonday);
	currMon.setHours(0, 0, 0, 0);

	// 2) Previous week: Monday → Sunday
	const prevMon = new Date(currMon);
	prevMon.setDate(currMon.getDate() - 7);
	prevMon.setHours(0, 0, 0, 0);
	const prevEnd = new Date(currMon);
	prevEnd.setMilliseconds(-1);  // just before currMon

	// 3) Compute deltas
	computeDeltaMetrics(currMon, today, prevMon, prevEnd)
	.then(rows => {
		const team = aggregateTeam(rows);
		renderDeltaTable("weeklyDeltaTbody", rows, team);
	});



	//
	// ─── MONTH‑OVER‑MONTH ───────────────────────────────────────────────
	//
	// 1) This month: 1st → today
	monthStart.setHours(0, 0, 0, 0);

	// 2) Previous month: 1st → last day
	const prevMonthStart = new Date(monthStart.getFullYear(), monthStart.getMonth() - 1, 1);
	prevMonthStart.setHours(0, 0, 0, 0);
	const prevMonthEnd = new Date(monthStart);
	prevMonthEnd.setMilliseconds(-1); // just before this monthStart

	// 3) Compute deltas
	computeDeltaMetrics(monthStart, today, prevMonthStart, prevMonthEnd)
	.then(rows => {
		console.log("MONTH‑OVER‑MONTH",rows);
		const team = aggregateTeam(rows);
		renderDeltaTable("monthlyDeltaTbody", rows, team);
	});


});
